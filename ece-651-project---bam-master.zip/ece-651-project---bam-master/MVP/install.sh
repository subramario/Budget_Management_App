
#!/bin/bash
sudo apt install python3-pip
sudo pip3 install requests
sudo pip3 install firebase
sudo pip3 install firebase-admin
sudo pip3 install pyrebase

