import React from "react";
import ReactDOM from 'react-dom';

export default function ResetPage() {
  return (
    <div>
      <h2>This is a reset page!</h2>
      <body>Replace with your own component!</body>      
    </div>
  );
}

