import React from "react";
import ReactDOM from 'react-dom';

export default function LoginPage() {
  return (
    <div>
      <h2>This is a login page!</h2>
      <body>Replace with your own component!</body>      
    </div>
  );
}

