import React from "react";
import ReactDOM from 'react-dom';

export default function SignUpPage() {
  return (
    <div>
      <h2>This is a signup page!</h2>
      <body>Replace with your own component!</body>      
    </div>
  );
}

