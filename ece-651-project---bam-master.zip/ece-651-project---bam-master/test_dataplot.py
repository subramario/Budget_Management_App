def test_dummy():
    return True
